# IT-Projektzentrale – Projektkontext

Aktuelle Version: 0.2.0

Ziel ist eine zentrale Empfangswebseite für alle Projekte von Markus. Die Anwendung präsentiert Projekte und dient zugleich als internes Software-Center für Debian-Pakete.

Technik: FastAPI, Jinja2, SQLite, Nginx auf Port 80, Uvicorn intern auf 127.0.0.1:8000, systemd.

Aktueller Stand:
- Dashboard
- Projektübersicht und Detailseiten
- Admin-Login
- Projektanlage
- DEB-Upload und Download
- Installation über apt-get
- Beispielprojekte

Nächste Aufgaben:
- sichere Passwortänderung in der Oberfläche
- Bearbeiten/Löschen von Projekten
- Paket-Signaturprüfung
- Backup vor Updates
- Dienststatus und Logs
- GitHub-/Gitea-Synchronisierung
- echtes Debian-Paket für die IT-Projektzentrale
