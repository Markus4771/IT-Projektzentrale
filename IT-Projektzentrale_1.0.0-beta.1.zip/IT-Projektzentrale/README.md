# IT-Projektzentrale 1.0.0 Beta 1

Zentrale Weboberfläche zur Verwaltung eigener Debian-Projekte. Eine Neuinstallation enthält keine Beispielprojekte.

## Hauptfunktionen

- Dashboard mit installierten Projekten und Direktlinks
- Projektverwaltung mit Archiv und Papierkorb
- GitHub-/Gitea-Releasequellen und lokale DEB-Pakete
- Installation, Update und Deinstallation
- systemd-Steuerung und Journal-Logs
- Projekt-Backups und Manifest-Import/-Export
- Systemstatus und Audit-Protokoll
- API unter `/api/v1/projects` und `/api/v1/system`

## Installation

```bash
sudo apt install ./it-projektzentrale_1.0.0-beta.1_all.deb
```

Aufruf anschließend über `http://SERVER-IP/`.
