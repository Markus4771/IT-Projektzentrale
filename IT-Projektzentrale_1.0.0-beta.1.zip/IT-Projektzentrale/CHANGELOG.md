# Changelog

## 1.0.0-beta.1
- Dashboard und leere Grundinstallation bleiben erhalten.
- Systemübersicht für Hostname, Last, RAM, Datenträger, Uptime und Raspberry-Pi-Temperatur.
- Projektbezogene Dienststeuerung: Start, Stopp und Neustart.
- Anzeige der letzten 200 systemd-Logzeilen pro Projekt.
- Projekt-Backups mit Manifest, Paketmetadaten und vorhandenen DEB-Dateien.
- Backup-Center mit Download und Löschen.
- Projektmanifest als JSON exportieren und importieren.
- Deinstallation installierter Debian-Pakete.
- Audit-Protokoll für kritische Verwaltungsaktionen.
- JSON-API für Projekte und Systemstatus.

## 0.4.1
- Dashboard-Kacheln für installierte Projekte, Direktlinks, Favoriten und Status.
