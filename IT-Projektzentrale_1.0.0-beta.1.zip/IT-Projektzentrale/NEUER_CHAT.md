Arbeite am Projekt „IT-Projektzentrale“.

Lies zuerst CHATGPT_PROJEKTKONTEXT.md, danach version.txt, README.md und CHANGELOG.md. Prüfe anschließend den tatsächlichen Quellcode.

Arbeite ausschließlich auf Basis des aktuellen Repository-Stands weiter. Bestätige zuerst Version, Ist-Stand und offene Aufgaben.


## Paketquellen
Die WebGUI unterstützt GitHub- und Gitea-Releases mit DEB-Anlagen sowie optionale Tokens für private Repositories.
